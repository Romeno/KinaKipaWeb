// nav.classList.toggle('is-opened');

// nav = document.getElementsByTagName('nav')[0]
// but = document.getElementsByClassName('hamburger')[0]

window.onload = function() {
    menu = function() {
        nav = document.getElementsByTagName('nav')[0]
        nav.classList.toggle('is-opened');
    }
}